// Default settings
const DEFAULT_SETTINGS = {
  targetUrl: 'https://app.your-login.com/v2/preview/AMicBk8O2aZ5a31n92HD',
  windowWidth: 200,
  windowHeight: 250,
  windowTop: 100,
  windowLeft: 100
};

// Listen for extension icon click
chrome.action.onClicked.addListener(() => {
  // Load settings from storage
  chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
    // Create window with user's saved settings
    chrome.windows.create({
      url: settings.targetUrl,
      type: 'popup',
      width: settings.windowWidth,
      height: settings.windowHeight,
      top: settings.windowTop,
      left: settings.windowLeft
    });
  });
});
