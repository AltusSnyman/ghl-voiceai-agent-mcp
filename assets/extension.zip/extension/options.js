// Default settings
const DEFAULT_SETTINGS = {
  targetUrl: 'https://app.your-login.com/v2/preview/AMicBk8O2aZ5a31n92HD',
  windowWidth: 200,
  windowHeight: 250,
  windowTop: 100,
  windowLeft: 100
};

// Load saved settings when page loads
document.addEventListener('DOMContentLoaded', loadSettings);

// Save settings when button clicked
document.getElementById('saveBtn').addEventListener('click', saveSettings);

// Reset to defaults when button clicked
document.getElementById('resetBtn').addEventListener('click', resetSettings);

function loadSettings() {
  chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
    document.getElementById('targetUrl').value = settings.targetUrl;
    document.getElementById('windowWidth').value = settings.windowWidth;
    document.getElementById('windowHeight').value = settings.windowHeight;
    document.getElementById('windowTop').value = settings.windowTop;
    document.getElementById('windowLeft').value = settings.windowLeft;
  });
}

function saveSettings() {
  const settings = {
    targetUrl: document.getElementById('targetUrl').value,
    windowWidth: parseInt(document.getElementById('windowWidth').value),
    windowHeight: parseInt(document.getElementById('windowHeight').value),
    windowTop: parseInt(document.getElementById('windowTop').value),
    windowLeft: parseInt(document.getElementById('windowLeft').value)
  };

  // Validate URL
  if (!settings.targetUrl || !isValidUrl(settings.targetUrl)) {
    showStatus('Please enter a valid URL', 'error');
    return;
  }

  // Validate dimensions
  if (settings.windowWidth < 200 || settings.windowHeight < 200) {
    showStatus('Width and height must be at least 200px', 'error');
    return;
  }

  // Save to Chrome storage
  chrome.storage.sync.set(settings, () => {
    showStatus('Settings saved successfully!', 'success');
  });
}

function resetSettings() {
  chrome.storage.sync.set(DEFAULT_SETTINGS, () => {
    loadSettings();
    showStatus('Settings reset to defaults', 'success');
  });
}

function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}

function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
  status.style.display = 'block';

  setTimeout(() => {
    status.style.display = 'none';
  }, 3000);
}
